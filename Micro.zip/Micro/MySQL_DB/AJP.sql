CREATE DATABASE student_db_backup;

USE student_db_backup;

CREATE TABLE register (
    id INT AUTO_INCREMENT PRIMARY KEY,
    Student_Name VARCHAR(100) NOT NULL,
    Branch VARCHAR(100) NOT NULL,
    Subject VARCHAR(100) NOT NULL,
    Year VARCHAR(10) NOT NULL
);

select * from register;
