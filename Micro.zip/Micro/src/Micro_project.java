import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Micro_project extends JDialog {

    private JTextField txtName, txtBranch, txtSubject, txtYear;
    private JButton btnRegister, btnCancel;
    Connection con, con2;
    PreparedStatement pst;

    public Micro_project(JFrame parent) {
        super(parent, "Student Registration", true);

        setSize(550, 450);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(52, 152, 219), 0, getHeight(), new Color(41, 128, 185));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);
        setContentPane(mainPanel);

        JPanel iconPanel = new JPanel();
        iconPanel.setBounds(215, 20, 120, 120);
        iconPanel.setBackground(new Color(41, 128, 185));
        iconPanel.setLayout(new BorderLayout());

        JLabel iconLabel = new JLabel("👨‍🎓", SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 70));
        iconLabel.setForeground(Color.WHITE);
        iconPanel.add(iconLabel);
        mainPanel.add(iconPanel);

        JLabel titleLabel = new JLabel("Student Registration");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(140, 150, 300, 35);
        mainPanel.add(titleLabel);

        JPanel formPanel = new JPanel(null);
        formPanel.setBounds(50, 200, 450, 160);
        formPanel.setBackground(new Color(255, 255, 255, 230));
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(41, 128, 185), 2));
        mainPanel.add(formPanel);

        addFormField(formPanel, "Student Name:", 20);
        txtName = addTextField(formPanel, 20);

        addFormField(formPanel, "Branch:", 55);
        txtBranch = addTextField(formPanel, 55);

        addFormField(formPanel, "Subject:", 90);
        txtSubject = addTextField(formPanel, 90);

        addFormField(formPanel, "Year:", 125);
        txtYear = addTextField(formPanel, 125);

        btnRegister = createButton("✅ Register", 120, 375, new Color(39, 174, 96));
        btnRegister.addActionListener(e -> registerStudent());
        mainPanel.add(btnRegister);

        btnCancel = createButton("❌ Cancel", 280, 375, new Color(231, 76, 60));
        btnCancel.addActionListener(e -> dispose());
        mainPanel.add(btnCancel);

        connect();

        setVisible(true);
    }

    private void addFormField(JPanel panel, String text, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        label.setForeground(new Color(52, 73, 94));
        label.setBounds(20, y, 120, 25);
        panel.add(label);
    }

    private JTextField addTextField(JPanel panel, int y) {
        JTextField textField = new JTextField();
        textField.setBounds(150, y, 280, 28);
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(189, 195, 199), 1),
                BorderFactory.createEmptyBorder(2, 5, 2, 5)
        ));
        panel.add(textField);
        return textField;
    }

    private JButton createButton(String text, int x, int y, Color bgColor) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 140, 40);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            Color originalColor = bgColor;
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor);
            }
        });

        return button;
    }

    private void registerStudent() {
        String name = txtName.getText().trim();
        String branch = txtBranch.getText().trim();
        String subject = txtSubject.getText().trim();
        String year = txtYear.getText().trim();

        if (name.isEmpty() || branch.isEmpty() || subject.isEmpty() || year.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "⚠️ Please fill all fields",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String sql = "INSERT INTO register(Student_Name, Branch, Subject, Year) VALUES (?, ?, ?, ?)";

            // Insert into primary database
//            pst = con.prepareStatement(sql);
//            pst.setString(1, name);
//            pst.setString(2, branch);
//            pst.setString(3, subject);
//            pst.setString(4, year);
//            pst.executeUpdate();
//            pst.close();

            // Insert into backup database
            pst = con2.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, branch);
            pst.setString(3, subject);
            pst.setString(4, year);
            pst.executeUpdate();
            pst.close();

            JOptionPane.showMessageDialog(this,
                    "✅ Registration Successful!\nOpening Currency Converter...",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            dispose();
            new Courrancy_Convertor();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "❌ Registration Failed\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            con2 = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/student_db_backup", "root", "Student@123");

            System.out.println("✅ Database Connected");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "❌ Database Connection Failed\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Micro_project(null));
    }
}