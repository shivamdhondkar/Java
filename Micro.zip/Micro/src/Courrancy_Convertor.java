import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class Courrancy_Convertor extends JFrame {

    private JComboBox<String> countryBox1, countryBox2;
    private JTextField textField1, textField2;
    private JLabel resultLabel;
    private JButton btnConvert, btnSwap, btnReset, btnClose;
    private DecimalFormat df = new DecimalFormat("#,##0.00");

    public Courrancy_Convertor() {
        setTitle("Currency Converter");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Main Panel with gradient
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(46, 204, 113), 0, getHeight(), new Color(39, 174, 96));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);
        setContentPane(mainPanel);

        // Title
        JLabel titleLabel = new JLabel("💱 Currency Converter");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(140, 20, 400, 40);
        mainPanel.add(titleLabel);

        // FROM Section
        JPanel fromPanel = createCurrencyPanel("From Currency:", 80);
        mainPanel.add(fromPanel);

        String[] countries = {
                "India", "USA", "UK", "Canada", "Australia",
                "Germany", "France", "Japan", "China", "Russia",
                "Brazil", "South Africa", "UAE", "Singapore", "Italy"
        };

        countryBox1 = new JComboBox<>(countries);
        countryBox1.setBounds(30, 35, 200, 35);
        countryBox1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        fromPanel.add(countryBox1);

        textField1 = new JTextField();
        textField1.setBounds(250, 35, 200, 35);
        textField1.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        textField1.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(189, 195, 199), 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        fromPanel.add(textField1);

        // Swap Button
        btnSwap = new JButton("⇅");
        btnSwap.setBounds(270, 200, 60, 40);
        btnSwap.setFont(new Font("Segoe UI", Font.BOLD, 24));
        btnSwap.setForeground(Color.WHITE);
        btnSwap.setBackground(new Color(52, 152, 219));
        btnSwap.setFocusPainted(false);
        btnSwap.setBorderPainted(false);
        btnSwap.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSwap.addActionListener(e -> swapCurrencies());
        mainPanel.add(btnSwap);

        // TO Section
        JPanel toPanel = createCurrencyPanel("To Currency:", 250);
        mainPanel.add(toPanel);

        countryBox2 = new JComboBox<>(countries);
        countryBox2.setSelectedIndex(1); // Default to USA
        countryBox2.setBounds(30, 35, 200, 35);
        countryBox2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        toPanel.add(countryBox2);

        textField2 = new JTextField();
        textField2.setBounds(250, 35, 200, 35);
        textField2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        textField2.setEditable(false);
        textField2.setBackground(new Color(236, 240, 241));
        textField2.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(189, 195, 199), 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        toPanel.add(textField2);

        // Result Label
        resultLabel = new JLabel("Enter amount and click Convert");
        resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        resultLabel.setForeground(Color.WHITE);
        resultLabel.setBounds(50, 360, 500, 30);
        resultLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(resultLabel);

        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(100, 400, 400, 50);
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));

        btnConvert = createActionButton("Convert", new Color(52, 152, 219));
        btnConvert.addActionListener(e -> convertCurrency());
        buttonPanel.add(btnConvert);

        btnReset = createActionButton("Reset", new Color(243, 156, 18));
        btnReset.addActionListener(e -> resetFields());
        buttonPanel.add(btnReset);

        btnClose = createActionButton("Close", new Color(231, 76, 60));
        btnClose.addActionListener(e -> System.exit(0));
        buttonPanel.add(btnClose);

        mainPanel.add(buttonPanel);

        setVisible(true);
    }

    private JPanel createCurrencyPanel(String title, int y) {
        JPanel panel = new JPanel(null);
        panel.setBounds(50, y, 500, 100);
        panel.setBackground(new Color(255, 255, 255, 230));
        panel.setBorder(BorderFactory.createLineBorder(new Color(39, 174, 96), 2));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(52, 73, 94));
        titleLabel.setBounds(20, 5, 200, 25);
        panel.add(titleLabel);

        return panel;
    }

    private JButton createActionButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(120, 40));
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            Color originalColor = bgColor;
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor);
            }
        });

        return button;
    }

    private void convertCurrency() {
        try {
            double amount = Double.parseDouble(textField1.getText().trim());

            if (amount <= 0) {
                JOptionPane.showMessageDialog(this,
                        "⚠️ Please enter a positive amount",
                        "Invalid Input",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            String from = countryBox1.getSelectedItem().toString();
            String to = countryBox2.getSelectedItem().toString();

            if (from.equals(to)) {
                textField2.setText(df.format(amount));
                resultLabel.setText("✓ Same currency - No conversion needed");
                return;
            }

            double inrAmount = convertToINR(from, amount);
            double finalAmount = convertFromINR(to, inrAmount);

            textField2.setText(df.format(finalAmount));
            resultLabel.setText(String.format("✓ %s %s = %s %s",
                    df.format(amount), getCurrencySymbol(from),
                    df.format(finalAmount), getCurrencySymbol(to)));

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "❌ Please enter a valid number",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            textField1.requestFocus();
        }
    }

    private void swapCurrencies() {
        int temp = countryBox1.getSelectedIndex();
        countryBox1.setSelectedIndex(countryBox2.getSelectedIndex());
        countryBox2.setSelectedIndex(temp);

        String tempText = textField1.getText();
        textField1.setText(textField2.getText());
        textField2.setText(tempText);

        if (!textField1.getText().isEmpty()) {
            convertCurrency();
        }
    }

    private void resetFields() {
        textField1.setText("");
        textField2.setText("");
        countryBox1.setSelectedIndex(0);
        countryBox2.setSelectedIndex(1);
        resultLabel.setText("Enter amount and click Convert");
    }

    private double convertToINR(String country, double amount) {
        switch (country) {
            case "USA": return amount * 83.0;
            case "UK": return amount * 105.0;
            case "UAE": return amount * 22.6;
            case "Japan": return amount * 0.56;
            case "Canada": return amount * 61.5;
            case "Australia": return amount * 54.8;
            case "Germany": return amount * 90.2;
            case "France": return amount * 90.2;
            case "China": return amount * 11.5;
            case "Russia": return amount * 0.89;
            case "Brazil": return amount * 16.8;
            case "South Africa": return amount * 4.5;
            case "Singapore": return amount * 61.7;
            case "Italy": return amount * 90.2;
            case "India": return amount;
            default: return amount * 80.0;
        }
    }

    private double convertFromINR(String country, double amount) {
        switch (country) {
            case "USA": return amount / 83.0;
            case "UK": return amount / 105.0;
            case "UAE": return amount / 22.6;
            case "Japan": return amount / 0.56;
            case "Canada": return amount / 61.5;
            case "Australia": return amount / 54.8;
            case "Germany": return amount / 90.2;
            case "France": return amount / 90.2;
            case "China": return amount / 11.5;
            case "Russia": return amount / 0.89;
            case "Brazil": return amount / 16.8;
            case "South Africa": return amount / 4.5;
            case "Singapore": return amount / 61.7;
            case "Italy": return amount / 90.2;
            case "India": return amount;
            default: return amount / 80.0;
        }
    }

    private String getCurrencySymbol(String country) {
        switch (country) {
            case "USA": return "USD";
            case "UK": return "GBP";
            case "UAE": return "AED";
            case "Japan": return "JPY";
            case "Canada": return "CAD";
            case "Australia": return "AUD";
            case "Germany": case "France": case "Italy": return "EUR";
            case "China": return "CNY";
            case "Russia": return "RUB";
            case "Brazil": return "BRL";
            case "South Africa": return "ZAR";
            case "Singapore": return "SGD";
            case "India": return "INR";
            default: return "";
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Courrancy_Convertor());
    }
}