import javax.swing.*;
import java.awt.*;

public class LandingPage extends JFrame {

    public LandingPage() {
        setTitle("Currency Converter System Student Level");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, new Color(41, 128, 185), 0, getHeight(), new Color(109, 213, 250));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);
        setContentPane(mainPanel);


        JLabel titleLabel = new JLabel("Currency Converter System Student Level");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(70, 40, 400, 40);
        mainPanel.add(titleLabel);

        JLabel subtitleLabel = new JLabel("Select Your Role");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(230, 245, 255));
        subtitleLabel.setBounds(180, 85, 200, 25);
        mainPanel.add(subtitleLabel);

        JButton userButton = createStyledButton("👤 User Login", 150, 150);
        userButton.addActionListener(e -> {
            dispose();
            new Micro_project(null);
        });
        mainPanel.add(userButton);

        JButton adminButton = createStyledButton("🔐 Admin Login", 150, 210);
        adminButton.addActionListener(e -> {
            dispose();
            new AdminLogin(); // hi yk file create karychi baki aahe ?
        });
        mainPanel.add(adminButton);

        // Exit Button
        JButton exitButton = createStyledButton("Exit", 150, 270);
        exitButton.setBackground(new Color(231, 76, 60));
        exitButton.addActionListener(e -> System.exit(0));
        mainPanel.add(exitButton);

        // Footer
        JLabel footerLabel = new JLabel("© 2026 Currency Converter System");
        footerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        footerLabel.setForeground(new Color(230, 245, 255));
        footerLabel.setBounds(140, 330, 250, 20);
        mainPanel.add(footerLabel);

        setVisible(true);
    }

    private JButton createStyledButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 45);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(52, 73, 94));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(44, 62, 80));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 73, 94));
            }
        });

        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new LandingPage();
        });
    }
}