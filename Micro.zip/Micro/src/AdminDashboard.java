import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class AdminDashboard extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JButton btnRefresh, btnDelete, btnUpdate, btnLogout;
    private Connection con;

    public AdminDashboard() {
        setTitle("Admin Dashboard - User Management");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(236, 240, 241));
        setContentPane(mainPanel);

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setPreferredSize(new Dimension(900, 80));
        headerPanel.setLayout(null);

        JLabel titleLabel = new JLabel("👨‍💼 Admin Dashboard");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(30, 20, 400, 40);
        headerPanel.add(titleLabel);

        btnLogout = createHeaderButton("Logout", 750, 25);
        btnLogout.addActionListener(e -> {
            dispose();
            new Admin();
        });
        headerPanel.add(btnLogout);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        String[] columns = {"ID", "Student Name", "Branch", "Subject", "Year"};
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(52, 73, 94));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(52, 152, 219));
        table.setSelectionForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(189, 195, 199), 1));
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(236, 240, 241));
        buttonPanel.setPreferredSize(new Dimension(900, 80));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 20));

        btnRefresh = createActionButton("🔄 Refresh", new Color(39, 174, 96));
        btnRefresh.addActionListener(e -> loadData());
        buttonPanel.add(btnRefresh);

        btnUpdate = createActionButton("✏️ Update", new Color(52, 152, 219));
        btnUpdate.addActionListener(e -> updateStudent());
        buttonPanel.add(btnUpdate);

        btnDelete = createActionButton("🗑️ Delete", new Color(231, 76, 60));
        btnDelete.addActionListener(e -> deleteStudent());
        buttonPanel.add(btnDelete);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        connectDatabase();
        loadData();

        setVisible(true);
    }

    private JButton createHeaderButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 120, 35);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(231, 76, 60));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JButton createActionButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(150, 40));
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            Color originalColor = bgColor;
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor);
            }
        });

        return button;
    }

    private void connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/student_db_backup", "root", "Student@123");
            System.out.println("✅ Database Connected");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "❌ Database Connection Failed\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadData() {
        model.setRowCount(0); // Clear existing data

        try {
            String sql = "SELECT * FROM register ORDER BY id DESC";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("id"),
                        rs.getString("Student_Name"),
                        rs.getString("Branch"),
                        rs.getString("Subject"),
                        rs.getString("Year")
                };
                model.addRow(row);
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "❌ Failed to load data\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateStudent() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "⚠️ Please select a student to update",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) model.getValueAt(selectedRow, 0);
        String name = (String) model.getValueAt(selectedRow, 1);
        String branch = (String) model.getValueAt(selectedRow, 2);
        String subject = (String) model.getValueAt(selectedRow, 3);
        String year = (String) model.getValueAt(selectedRow, 4);

        // Create update dialog
        JTextField txtName = new JTextField(name);
        JTextField txtBranch = new JTextField(branch);
        JTextField txtSubject = new JTextField(subject);
        JTextField txtYear = new JTextField(year);

        Object[] fields = {
                "Student Name:", txtName,
                "Branch:", txtBranch,
                "Subject:", txtSubject,
                "Year:", txtYear
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "Update Student",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (option == JOptionPane.OK_OPTION) {
            try {
                String sql = "UPDATE register SET Student_Name=?, Branch=?, Subject=?, Year=? WHERE id=?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, txtName.getText().trim());
                pst.setString(2, txtBranch.getText().trim());
                pst.setString(3, txtSubject.getText().trim());
                pst.setString(4, txtYear.getText().trim());
                pst.setInt(5, id);
                pst.executeUpdate();
                pst.close();

                JOptionPane.showMessageDialog(this, "✅ Student updated successfully!");
                loadData();

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "❌ Update failed\n" + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteStudent() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "⚠️ Please select a student to delete",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) model.getValueAt(selectedRow, 0);
        String name = (String) model.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete " + name + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM register WHERE id=?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setInt(1, id);
                pst.executeUpdate();
                pst.close();

                JOptionPane.showMessageDialog(this, "✅ Student deleted successfully!");
                loadData();

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "❌ Delete failed\n" + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminDashboard());
    }
}