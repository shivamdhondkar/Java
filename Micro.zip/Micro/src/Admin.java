import javax.swing.*;
import java.awt.*;

public class Admin extends JFrame {

    public Admin() {
        setTitle("Currency Converter System Student Level");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, new Color(41, 128, 185), 0, getHeight(), new Color(109, 213, 250));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);
        setContentPane(mainPanel);

        JLabel titleLabel = new JLabel("Currency Converter System Student Level");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(70, 40, 400, 40);
        mainPanel.add(titleLabel);


        JLabel subtitleLabel = new JLabel("Select Your Role");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(230, 245, 255));
        subtitleLabel.setBounds(180, 85, 200, 25);
        mainPanel.add(subtitleLabel);


        JButton userButton = createStyledButton("👤 User Login", 150, 150);
        userButton.addActionListener(e -> {
            dispose();
            new Micro_project(null);
        });
        mainPanel.add(userButton);

        JButton adminButton = createStyledButton("🔐 Admin Login", 150, 210);
        adminButton.addActionListener(e -> {
            dispose();
            showAdminLogin();
        });
        mainPanel.add(adminButton);

        JButton exitButton = createStyledButton("Exit", 150, 270);
        exitButton.setBackground(new Color(231, 76, 60));
        exitButton.addActionListener(e -> System.exit(0));
        mainPanel.add(exitButton);

        JLabel footerLabel = new JLabel("© 2026 Currency Converter System");
        footerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        footerLabel.setForeground(new Color(230, 245, 255));
        footerLabel.setBounds(140, 330, 250, 20);
        mainPanel.add(footerLabel);

        setVisible(true);
    }

    private JButton createStyledButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 45);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(52, 73, 94));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(44, 62, 80));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(52, 73, 94));
            }
        });

        return button;
    }

    private void showAdminLogin() {
        JDialog loginDialog = new JDialog(this, "Admin Login", true);
        loginDialog.setSize(450, 350);
        loginDialog.setLocationRelativeTo(null);
        loginDialog.setResizable(false);

        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(52, 73, 94), 0, getHeight(), new Color(44, 62, 80));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);
        loginDialog.setContentPane(mainPanel);

        JPanel iconPanel = new JPanel();
        iconPanel.setBounds(165, 30, 120, 120);
        iconPanel.setBackground(new Color(41, 128, 185));
        iconPanel.setLayout(new BorderLayout());

        JLabel iconLabel = new JLabel("🔐", SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 60));
        iconLabel.setForeground(Color.WHITE);
        iconPanel.add(iconLabel);
        mainPanel.add(iconPanel);

        JLabel titleLabel = new JLabel("Admin Login");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(160, 160, 150, 30);
        mainPanel.add(titleLabel);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUsername.setForeground(Color.WHITE);
        lblUsername.setBounds(80, 200, 80, 25);
        mainPanel.add(lblUsername);

        JTextField txtUsername = new JTextField();
        txtUsername.setBounds(170, 200, 180, 30);
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        mainPanel.add(txtUsername);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPassword.setForeground(Color.WHITE);
        lblPassword.setBounds(80, 240, 80, 25);
        mainPanel.add(lblPassword);

        JPasswordField txtPassword = new JPasswordField();
        txtPassword.setBounds(170, 240, 180, 30);
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        mainPanel.add(txtPassword);

        JButton btnLogin = createDialogButton("Login", 100, 285, new Color(39, 174, 96));
        btnLogin.addActionListener(e -> {
            String username = txtUsername.getText().trim();
            String password = new String(txtPassword.getPassword());

            if (username.equals("admin") && password.equals("admin123")) {
                JOptionPane.showMessageDialog(loginDialog,
                        "✅ Login Successful!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                loginDialog.dispose();
                new AdminDashboard();
            } else {
                JOptionPane.showMessageDialog(loginDialog,
                        "❌ Invalid username or password!",
                        "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
                txtPassword.setText("");
            }
        });
        mainPanel.add(btnLogin);

        JButton btnBack = createDialogButton("Back", 230, 285, new Color(192, 57, 43));
        btnBack.addActionListener(e -> {
            loginDialog.dispose();
            new Admin();
        });
        mainPanel.add(btnBack);

        loginDialog.setVisible(true);
    }

    private JButton createDialogButton(String text, int x, int y, Color bgColor) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 120, 35);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Admin();
        });
    }
}