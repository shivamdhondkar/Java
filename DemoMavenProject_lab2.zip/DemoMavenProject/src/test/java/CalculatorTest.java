import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CalculatorTest {

    Calculator calc = new Calculator();

    @Test
    public void testAddPositiveNumbers() {
        assertEquals(10, calc.add(5, 5));
    }

    @Test
    public void testAddNegativeNumbers() {
        assertEquals(-8, calc.add(-5, -3));
    }

    @Test
    public void testSubtractPositiveNumbers() {
        assertEquals(2, calc.subtract(5, 3));
    }

    @Test
    public void testSubtractNegativeNumbers() {
        assertEquals(8, calc.subtract(5, -3));
    }
}
