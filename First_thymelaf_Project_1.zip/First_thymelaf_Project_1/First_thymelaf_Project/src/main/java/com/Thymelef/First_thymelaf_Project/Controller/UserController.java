package com.Thymelef.First_thymelaf_Project.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class UserController {

//    @GetMapping("/show")
//    public String show(Model model) {
//
//        String str = "Hello Gyzs..! Wake Up";
//
//        String str1 = "Shital Pawar";
//
//        model.addAttribute("name",str);
//        model.addAttribute("Name_chnage",str1);
//        return "show";
//
//
//    }

    @GetMapping("/show/{user_age}")
    public String show(@PathVariable int user_age, Model model) {
        int Student_Age = user_age;

        model.addAttribute("name",Student_Age);
        return "show";
    }
}
