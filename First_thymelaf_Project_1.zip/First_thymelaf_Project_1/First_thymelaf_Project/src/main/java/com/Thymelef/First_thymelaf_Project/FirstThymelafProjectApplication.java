package com.Thymelef.First_thymelaf_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstThymelafProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstThymelafProjectApplication.class, args);

		System.out.println("Hello World");
	}

}
