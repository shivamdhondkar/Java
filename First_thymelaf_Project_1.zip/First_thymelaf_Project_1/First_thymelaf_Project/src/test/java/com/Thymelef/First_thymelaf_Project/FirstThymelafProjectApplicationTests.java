package com.Thymelef.First_thymelaf_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstThymelafProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
