package MavenEx;

public class MavenExample {
    public static void main(String[] args) {
        System.out.println("Welcome to Maven");
    }
}
