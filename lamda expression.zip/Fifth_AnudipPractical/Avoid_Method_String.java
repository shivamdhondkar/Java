package Fifth_AnudipPractical;

import java.util.Scanner;

 interface String_Operation {
     String operate (String str);
 }

public class Avoid_Method_String {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String: ");
        String User_str = sc.nextLine();

        String_Operation toupperCase = str -> str.toUpperCase();
        String_Operation LowerCase =  str -> str.toLowerCase();

        String_Operation reverseOFstring = str1 -> {
            StringBuilder sb = new StringBuilder(str1);
            return sb.reverse().toString();
        };

        System.out.println("User String: "+User_str);
        System.out.println("String Upercase: "+toupperCase.operate(User_str));
        System.out.println("String Lowercase: "+LowerCase.operate(User_str));
        System.out.println("Reverse String: "+reverseOFstring.operate(User_str));
    }
}
