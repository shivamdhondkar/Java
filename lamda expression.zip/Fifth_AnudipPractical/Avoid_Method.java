package Fifth_AnudipPractical;

import java.util.Scanner;

interface Arithmatic_Operation{
     double operate(double a, double b);
}

public class Avoid_Method {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the First Number: ");
        double num1 = sc.nextDouble();

        System.out.println("Enter the Secound Number: ");
        double num2 = sc.nextDouble();

        Arithmatic_Operation addition = (a, b) -> a + b;
        Arithmatic_Operation subtarction = (a, b) -> a - b;
        Arithmatic_Operation Multiplication = (a, b) -> a * b;
        Arithmatic_Operation Divison = (a, b) -> {

            if (b == 0) {
                System.out.println("Not Divide 0");
                return 0;
            }
            return a / b;
        };

        System.out.println("Addition : " + addition.operate(num1, num2));
        System.out.println("Subtraction: "+subtarction.operate(num1,num2));
        System.out.println("Multiplication: "+Multiplication.operate(num1, num2));
        System.out.println("Division: "+Divison.operate(num1,num2));
    }
}
